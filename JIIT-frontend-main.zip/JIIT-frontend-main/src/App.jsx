import './App.css'
import Login from './components/Login'
import Signup from './components/Signup'
import Event from './components/Event'
import MyEvent from './components/MyEvent'
function App() {

  return (
    <>
      {/* <Login/> */}
      {/* <Signup/> */}
      {/* <Event/> */}
      <MyEvent/>
    </>
  )
}

export default App
